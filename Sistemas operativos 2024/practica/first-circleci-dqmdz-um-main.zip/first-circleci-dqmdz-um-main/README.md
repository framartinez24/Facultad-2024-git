# first-circleci-dqmdz-um
first-circleci-dqmdz-um created by GitHub Classroom

# CircleCI
[![CircleCI](https://dl.circleci.com/status-badge/img/gh/um-computacion-tm/first-circleci-dqmdz-um/tree/main.svg?style=svg)](https://dl.circleci.com/status-badge/redirect/gh/um-computacion-tm/first-circleci-dqmdz-um/tree/main)

# Maintainability
[![Maintainability](https://api.codeclimate.com/v1/badges/9c414a712013b7e20317/maintainability)](https://codeclimate.com/github/um-computacion-tm/first-circleci-dqmdz-um/maintainability)

# Test Coverage
[![Test Coverage](https://api.codeclimate.com/v1/badges/9c414a712013b7e20317/test_coverage)](https://codeclimate.com/github/um-computacion-tm/first-circleci-dqmdz-um/test_coverage)